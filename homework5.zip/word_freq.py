#!/usr/bin/python

f=open("word.txt",'w')
f.write("""summer is coming
        summer is my favorite
        wanna be a developer
        go to world
        hello world
        in to the unknown
        summer summer summer
        a be coming
        to to
        be a hero""")
f.close()

filename=input("파일 이름을 입력하세요 : ")
num=int(input("정수를 입력하세요 : "))


from collections import Counter

f = open(filename,'r')

text = f.read()
wordlist = text.split()

counts=dict()

for word in wordlist:
    counts[word]=counts.get(word,0)+1
print(counts)

result=Counter(wordlist)

tag_count = []
tags=[]

most_word=result.most_common(num)

print(most_word)

for n, c in most_word:
    dics={'tag':n,'count':c}
    if len(dics['tag'])>=1 and len(tags) <=49:
            tag_count.append(dics)
            tags.append(dics['tag'])


for tag in tag_count:
    print("{:<14}".format(tag['tag']),end='\t')
    print("{}".format(tag['count']))

