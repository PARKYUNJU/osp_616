#!/bin/bash
#2022-03-24
#select command example

select var in alpha beta gamma
do
	echo $var
done

