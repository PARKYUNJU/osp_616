#include <stdio.h>
int main(int argc, char*arvc[])
{
	int i;
	printf("#of argc:%d\n",argc);

	for(i=0;i<argc;i++)
	{
		printf("arc[%d]: %s\n",i,arvc[i]);
	}
}

