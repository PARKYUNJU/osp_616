#!/bin/bash
#2022-03-21
#if-then-else statement + less than
read -p "Enter years of workd: " Years
if [ ! "$Years" -lt 20 ]; then
	echo "You can retire now"
else
	echo "You need 20+ years to retire"
fi

