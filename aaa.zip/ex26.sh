#!/bin/bash
#2022-03-24
#array example

declare -a sports
sports={ball frisbee puck}
for i in "${!sports[@]}";
do
	echo "$i";
done

echo "the array contains ${#sports[@]} elements"

sports+=(soccer vaseball)
echo ${sports[*]}

unset sports[1]
echo ${sports[*]}

unset sports
echo ${sports[*]}

