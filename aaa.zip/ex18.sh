#!/bin/bash
#2022-03-24
#function example

# A somewhat more complex function
fun(){
	JUST_A_SECOND=1
	let i=0
	REPEATS=30
	echo "And now the fun really begins."
	while [ $i -lt $REPEATS ]
	do
		echo "------------FUNTIONS are fun------------->"
		sleep $JUST_A_SECOND
		let i+=1
	done
}

# run funtion
fun

