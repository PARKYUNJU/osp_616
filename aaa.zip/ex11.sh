#!/bin/bash
#202-03-24
#for-loop-example
for i in 7 9 2 4 3 5
do
	echo $i
done

