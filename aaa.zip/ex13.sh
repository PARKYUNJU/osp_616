#!/bin/bash
#2022-03-24
#interating over paramaters

for parm
do
	echo $parm
done

