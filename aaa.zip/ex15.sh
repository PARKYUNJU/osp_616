#!/bin/bash
#2022-03-24
#select command example2

# set PS3 prompt

PS3="Enter the space shuttle name : "

# set shuttle list
select shuttle in columbia endeavour challen get discovery atlantis enterprise pathfinder
do
	echo "$shuttle selected"
done
