
#!/bin/bash
echo "Hello world"
pwd
ls -al

