#!/bin/bash
#2022-03-22
#until example2

Stop="N"
until [ $Stop = "Y" ]; do
	ps -A
	read -p "want to stop?(Y/N)" reply
	Stop='echo $reply | tr [:lower:] [:upper:]'
done
echo "done"

