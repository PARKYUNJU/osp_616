#!/usr/bin/python
import sys


list=[]
sum=0
n=int(input("how many numbers : "))
for i in range(n):
    num=int(input(f"{i+1}번째: "))

    list.append(num)

for i in list:
    sum += i

avg = sum/n


print(avg)


