#!usr/bin/python

import sys

n=int(input("피보나치 수를 입력하세요: "))

def fibo(n):
    a = 1
    b = 1
    if n == 1 or n == 2:
        return 1
    else:
        return fibo(n-1) + fibo(n-2)



for i in range(1,n+1):
    print(fibo(i))
print("F%d : %d" %(n, fibo(n)))        


